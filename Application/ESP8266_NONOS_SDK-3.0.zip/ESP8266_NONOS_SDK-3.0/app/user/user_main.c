/*
 * ESPRESSIF MIT License
 *
 * Copyright (c) 2016 <ESPRESSIF SYSTEMS (SHANGHAI) PTE LTD>
 *
 * Permission is hereby granted for use on ESPRESSIF SYSTEMS ESP8266 only, in which case,
 * it is free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the Software is furnished
 * to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#include "ets_sys.h"
#include "osapi.h"

#include "user_interface.h"

#include "user_config.h"

#ifdef FOTA
#if ((SPI_FLASH_SIZE_MAP == 0) || (SPI_FLASH_SIZE_MAP == 1))
#error "The flash map is not supported"
#elif (SPI_FLASH_SIZE_MAP == 2)
#define SYSTEM_PARTITION_OTA_SIZE							0x6A000
#define SYSTEM_PARTITION_OTA_2_ADDR							0x81000
#define SYSTEM_PARTITION_RF_CAL_ADDR						0xfb000
#define SYSTEM_PARTITION_PHY_DATA_ADDR						0xfc000
#define SYSTEM_PARTITION_SYSTEM_PARAMETER_ADDR				0xfd000
#define SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM_ADDR           0x7c000
#elif (SPI_FLASH_SIZE_MAP == 3)
#define SYSTEM_PARTITION_OTA_SIZE							0x6A000
#define SYSTEM_PARTITION_OTA_2_ADDR							0x81000
#define SYSTEM_PARTITION_RF_CAL_ADDR						0x1fb000
#define SYSTEM_PARTITION_PHY_DATA_ADDR						0x1fc000
#define SYSTEM_PARTITION_SYSTEM_PARAMETER_ADDR				0x1fd000
#define SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM_ADDR           0x7c000
#elif (SPI_FLASH_SIZE_MAP == 4)
#define SYSTEM_PARTITION_OTA_SIZE							0x6A000
#define SYSTEM_PARTITION_OTA_2_ADDR							0x81000
#define SYSTEM_PARTITION_RF_CAL_ADDR						0x3fb000
#define SYSTEM_PARTITION_PHY_DATA_ADDR						0x3fc000
#define SYSTEM_PARTITION_SYSTEM_PARAMETER_ADDR				0x3fd000
#define SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM_ADDR           0x7c000
#elif (SPI_FLASH_SIZE_MAP == 5)
#define SYSTEM_PARTITION_OTA_SIZE							0x6A000
#define SYSTEM_PARTITION_OTA_2_ADDR							0x101000
#define SYSTEM_PARTITION_RF_CAL_ADDR						0x1fb000
#define SYSTEM_PARTITION_PHY_DATA_ADDR						0x1fc000
#define SYSTEM_PARTITION_SYSTEM_PARAMETER_ADDR				0x1fd000
#define SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM_ADDR           0xfc000
#elif (SPI_FLASH_SIZE_MAP == 6)
#define SYSTEM_PARTITION_OTA_SIZE							0x6A000
#define SYSTEM_PARTITION_OTA_2_ADDR							0x101000
#define SYSTEM_PARTITION_RF_CAL_ADDR						0x3fb000
#define SYSTEM_PARTITION_PHY_DATA_ADDR						0x3fc000
#define SYSTEM_PARTITION_SYSTEM_PARAMETER_ADDR				0x3fd000
#define SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM_ADDR           0xfc000
#else
#error "The flash map is not supported"
#endif

#define SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM                SYSTEM_PARTITION_CUSTOMER_BEGIN

uint32 priv_param_start_sec;

static const partition_item_t at_partition_table[] = {
    { SYSTEM_PARTITION_BOOTLOADER, 						0x0, 												0x1000},
    { SYSTEM_PARTITION_OTA_1,   						0x1000, 											SYSTEM_PARTITION_OTA_SIZE},
    { SYSTEM_PARTITION_OTA_2,   						SYSTEM_PARTITION_OTA_2_ADDR, 						SYSTEM_PARTITION_OTA_SIZE},
    { SYSTEM_PARTITION_RF_CAL,  						SYSTEM_PARTITION_RF_CAL_ADDR, 						0x1000},
    { SYSTEM_PARTITION_PHY_DATA, 						SYSTEM_PARTITION_PHY_DATA_ADDR, 					0x1000},
    { SYSTEM_PARTITION_SYSTEM_PARAMETER, 				SYSTEM_PARTITION_SYSTEM_PARAMETER_ADDR, 			0x3000},
    { SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM,             SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM_ADDR,          0x1000},
};

void ICACHE_FLASH_ATTR user_pre_init(void)
{
    if(!system_partition_table_regist(at_partition_table, sizeof(at_partition_table)/sizeof(at_partition_table[0]),SPI_FLASH_SIZE_MAP)) {
		os_printf("system_partition_table_regist fail\r\n");
		while(1);
	}
}

#endif


#ifdef NON_FOTA

#if (CHIP_TYPE == 8285)

#define FLASH_SIZE_MAP  										FLASH_SIZE_8M_MAP_512_512
#define SYSTEM_PARTITION_RF_CAL_ADDR		                    0xfb000
#define SYSTEM_PARTITION_PHY_DATA_ADDR	                        0xfc000
#define SYSTEM_PARTITION_SYSTEM_PARAMETER_ADDR                  0xfd000
#define EAGLE_FLASH_BIN_ADDR									(SYSTEM_PARTITION_CUSTOMER_BEGIN + 1)
#define EAGLE_IROM0TEXT_BIN_ADDR								(SYSTEM_PARTITION_CUSTOMER_BEGIN + 2)
#define SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM_ADDR           	0x71000   	//0x7C000
#define SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM                	SYSTEM_PARTITION_CUSTOMER_BEGIN

static const partition_item_t partition_table[] = {
    { EAGLE_FLASH_BIN_ADDR, 	0x00000, 0x10000},
    { EAGLE_IROM0TEXT_BIN_ADDR, 0x10000, 0x60000},
    { SYSTEM_PARTITION_RF_CAL, SYSTEM_PARTITION_RF_CAL_ADDR, 0x1000},
    { SYSTEM_PARTITION_PHY_DATA, SYSTEM_PARTITION_PHY_DATA_ADDR, 0x1000},
    { SYSTEM_PARTITION_SYSTEM_PARAMETER,SYSTEM_PARTITION_SYSTEM_PARAMETER_ADDR, 0x3000},
    { SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM,SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM_ADDR,0x8000},
};


#elif (CHIP_TYPE == 8266)

#define FLASH_SIZE_MAP 											FLASH_SIZE_32M_MAP_512_512
#define SYSTEM_PARTITION_RF_CAL_ADDR		                    0xfb000
#define SYSTEM_PARTITION_PHY_DATA_ADDR	                        0xfc000
#define SYSTEM_PARTITION_SYSTEM_PARAMETER_ADDR                  0xfd000
#define EAGLE_FLASH_BIN_ADDR									(SYSTEM_PARTITION_CUSTOMER_BEGIN + 1)
#define EAGLE_IROM0TEXT_BIN_ADDR								(SYSTEM_PARTITION_CUSTOMER_BEGIN + 2)
#define SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM_ADDR           	0x71000
#define SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM                	SYSTEM_PARTITION_CUSTOMER_BEGIN

static const partition_item_t partition_table[] = {
    { EAGLE_FLASH_BIN_ADDR, 	0x00000, 0x10000},
    { EAGLE_IROM0TEXT_BIN_ADDR, 0x10000, 0x60000},
    { SYSTEM_PARTITION_RF_CAL, SYSTEM_PARTITION_RF_CAL_ADDR, 0x1000},
    { SYSTEM_PARTITION_PHY_DATA, SYSTEM_PARTITION_PHY_DATA_ADDR, 0x1000},
    { SYSTEM_PARTITION_SYSTEM_PARAMETER,SYSTEM_PARTITION_SYSTEM_PARAMETER_ADDR, 0x3000},
    { SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM,SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM_ADDR,0x8000},
};

#endif
#endif

void ICACHE_FLASH_ATTR user_pre_init(void)
{
    if(!system_partition_table_regist(partition_table, sizeof(partition_table)/sizeof(partition_table[0]),FLASH_SIZE_MAP)) {
		os_printf("system_partition_table_regist fail\r\n");
		while(1) ;
	}
}


/******************************************************************************
 * FunctionName : user_init
 * Description  : entry of user application, init user function here
 * Parameters   : none
 * Returns      : none
*******************************************************************************/

#include "user_common.h"
#include "user_config.h"

#include "user_ILI9341.h"
#include "user_ssd1306.h"
#include "user_xpt2046.h"
#include "user_sht3x.h"

uint32 priv_param_start_sec;

extern struct mycfg CFG ;
extern bool bMyCFG;

void ICACHE_FLASH_ATTR
user_init(void)
{
    partition_item_t partition_item;
    os_printf("SDK version:%s\n", system_get_sdk_version());

    if (!system_partition_get_item(SYSTEM_PARTITION_CUSTOMER_PRIV_PARAM, &partition_item)) {
        os_printf("Get partition information fail\n");
    }
    priv_param_start_sec = partition_item.addr/SPI_FLASH_SEC_SIZE;

     os_printf("SDK version:%s\n", system_get_sdk_version());

    os_printf("Boot version:%u\n", system_get_boot_version());

    os_printf("CPU frequency:%uMHz\n", system_get_cpu_freq());

    os_printf("Flash and map size:\n  ");
    switch(system_get_flash_size_map()){
    case 0:
        os_printf("4Mb 256KB+256KB \n");
    	break;
    case 1:
        os_printf("2Mb \n", system_get_cpu_freq());
    	break;
    case 2:
        os_printf("8Mb 512KB+512KB \n");
    	break;
    case 3:
        os_printf("16Mb 512KB+512KB \n");
    	break;
    case 4:
        os_printf("32Mb 512KB+512KB \n");
    	break;
    case 5:
        os_printf("16Mb 1024KB+1024KB \n");
    	break;
    case 6:
        os_printf("32Mb 1024KB+1024KB \n");
    	break;
    case 7:
        os_printf("64Mb 1024KB+1024KB \n");
    	break;
    case 8:
        os_printf("128Mb 1024KB+1024KB  \n");
    	break;
    default:
    	break;
    }

    os_printf("Hostname:%s \n", wifi_station_get_hostname());

    os_printf("WIFI physical-layer mode:\n  ");
    switch(wifi_get_phy_mode()){
    case 1:
        os_printf("802.11B \n");
    	break;
    case 2:
        os_printf("802.11G \n");
    	break;
    case 3:
        os_printf("802.11N \n");
    	break;
    default:
    	break;
    }

    os_printf("System memory:\n");
    system_print_meminfo();

    os_printf("\n");


    /*added by spark.    */

	char cfg[500];

	os_memset(&CFG,0,sizeof(struct mycfg));

	if(!read_mycfg_from_flash())
		os_printf("read_cfg failed!!!!!!!!!!!!!! \r\n");
	else if(os_strcmp(CFG.flag,CFG_MAGIC) != 0)
		os_memset(&CFG,0,sizeof(struct mycfg));
	else
		bMyCFG = true;

	os_printf("\r\n***************************************************** \r\n");
	os_printf("%s",get_configuration(cfg,500));
	os_printf("***************************************************** \r\n\r\n");

#if defined(_XPT2046)||defined(_ILI9341)
    hspi_init(0,10*1000*1000);
#endif

#ifdef _ILI9341					//SPI
	ILI9341_init(15,9,10,240,320,ILI9341_BLUE);
#endif

#ifdef _XPT2046					//SPI
    xpt2046_init(0,5,240,320);
    xpt2046_setCalibration(209, 1759, 1775, 273);
#endif

#if defined(_SSD1306)||defined(_SHT3X)
#if (CHIP_TYPE == 8266)
    i2c_pin(0,2);
#elif (CHIP_TYPE == 8285)
    i2c_pin(4,2);
#endif
#endif

#ifdef _SSD1306
    ssd1306_init();     	//  I2C
#endif

#ifdef _SHT3X
    sht3x_init();			//	I2C
#endif

#ifdef _TEST
    user_test();
#endif

    tcpuser_init();
}

