
#include "user_config.h"

#ifdef _TEST

#include "ets_sys.h"
#include "osapi.h"
#include "os_type.h"

#include "user_common.h"

#include "user_ILI9341.h"
#include "user_ssd1306.h"
#include "user_xpt2046.h"
#include "user_sht3x.h"

extern struct mycfg CFG ;
extern bool have_ssd1306;

#ifdef _ILI9341
extern const unsigned char g[7198];
LOCAL os_timer_t display_time_timer;
struct datetime _old;

u8 sw = 0;
uint16_t R = 0;
uint16_t G = 0;
uint16_t B = 0;

uint16_t x = 0;
uint16_t y = 0;
uint16_t i = 0;

char buff[32];

void
display_time_cb(void)
{
	++i;

	struct datetime *now = (struct datetime *)get_sys_time();
	u8 x_begin = 50;
	u8 y_begin = 10;

	if(now){
		os_memset(buff,0,32);
		if(now->year != _old.year || now->month != _old.month || now->day != _old.day ){
			os_sprintf(buff," %d-%d-%d ",now->year+2018,now->month,now->day);

			sw = ILI9341_drawString(buff,x_begin,y_begin,16);

			_old.year = now->year;
			_old.month = now->month;
			_old.day = now->day;
//			os_printf("%s \r\n",buff);
		}

		if(now->hour != _old.hour || now->minute != _old.minute || now->second != _old.second){

			os_sprintf(buff+16,"%2d:%02d:%02d ",now->hour,now->minute,now->second);

			x_begin = x_begin+sw;

			ILI9341_drawString(buff+16,x_begin,y_begin,16);

			_old.hour = now->hour;
			_old.minute = now->minute;
			_old.second = now->second;
//			os_printf("%s,begin=%u \r\n",buff+16,x_begin);
		}
	}


	if (i % 10 == 9) {

		os_memset(buff,0,32);
		os_sprintf(buff, "RGB [%02X%02X%02X]",R,G,B);
		ILI9341_fillCircle(75, 200, 50, ILI9341_color565(R, G, B));
		ILI9341_drawString(buff, 20, 260, 16);

		B+=8;

		if (0xff <= B) { G+=4; B = 0;}
		if (0xff < G ) { R+=8; G =0; }
		if (0xff < R) { R = 0; }
	}

#ifdef _XPT2046
	xpt2046_getPosition(&x,&y);

	if(xpt2046_isTouching()){
		os_printf("touching...\r\n");
	}

	if (x < 240 && y < 320) {
		os_memset(buff,0,32);
		os_sprintf(buff, " (%u,%u)     ",x,y);
		os_printf("%s \r\n",buff);
#ifdef _ILI9341
		ILI9341_drawString(buff, 90, 40 ,16);
#endif
	}
#endif
}
#endif

#ifdef _SSD1306

LOCAL os_timer_t display_TH_timer;

s16 t_part1 = 0;
s16 t_part2 = 0;
u8 h_part1 = 0;
u8 h_part2 = 0;
struct datetime old;
char title[16] = {0};
u8 len = 0;
u32 nCounts = 0;
bool is_conn = false;

extern s32 SHT3X_T ;
extern s32 SHT3X_H ;
extern struct mycfg CFG ;
extern struct espconn *conn;
extern bool have_sht3x;

void
display_TH_cb(void)
{
	s32 temperature = 0;
	s32 humidity = 0;
	char buff[32] = {0};
	struct datetime *now = (struct datetime *)get_sys_time();
	u8 x_begin = 1;
	u8 i = 0;

	u8 cur = 0;

	++nCounts;

//	if(now){
//		cur = now->hour < oled_off_begin?(now->hour+24):now->hour;
//		if(oled_off && (cur < oled_off_begin || cur >= oled_off_end)){
//			ssd1306_display_on();
//			oled_off = false;
//		}else if(!oled_off && cur >= oled_off_begin && cur< oled_off_end){
//			ssd1306_display_off();
//			oled_off = true;
//		}
//	}
//
//	if(oled_off)
//		return;

	if(cfg_is_enable(CFG.enable,7) && os_strcmp(CFG.display_title,title) != 0){
		ssd1306_display_string(x_begin,3,CFG.display_title,12,1);
		ssd1306_refresh_gram2(x_begin,127,48,63);
		os_memcpy(title,CFG.display_title,16);
	}else if(now){
		os_memset(buff,0,32);
		if(now->year != old.year || now->month != old.month || now->day != old.day ){
			os_sprintf(buff,"%d-%d-%d ",now->year+2018,now->month,now->day);
			len = os_strlen(buff);
			ssd1306_display_string(x_begin,3,buff,12,1);
			ssd1306_refresh_gram2(x_begin,5+len*6,48,63);
			old.year = now->year;
			old.month = now->month;
			old.day = now->day;
//			os_printf("%s \r\n",buff);
		}

		if(now->hour != old.hour){
			os_sprintf(buff+16,"%2d:%02d:%02d ",now->hour,now->minute,now->second);

			x_begin = x_begin+(len)*6;
			ssd1306_display_string(x_begin,3,buff+16,12,1);
			ssd1306_refresh_gram2(x_begin,x_begin+10*6,48,63);
			old.hour = now->hour;
			old.minute = now->minute;
			old.second = now->second;
//			os_printf("%s,begin=%u \r\n",buff+16,x_begin);
		}else if(now->minute != old.minute){
			os_sprintf(buff+16,"%02d:%02d",now->minute,now->second);
			x_begin = x_begin+(len+2+1)*6;
			ssd1306_display_string(x_begin,3,buff+16,12,1);
			ssd1306_refresh_gram2(x_begin,x_begin+5*6,48,63);
			old.minute = now->minute;
			old.second = now->second;
//			os_printf("%s,begin=%u \r\n",buff+16,x_begin);
		}else if(now->second != old.second){
			os_sprintf(buff+16,"%02d",now->second);
			x_begin = x_begin+(len+2+4)*6;
			ssd1306_display_string(x_begin,3,buff+16,12,1);
			ssd1306_refresh_gram2(x_begin,x_begin+2*6,48,63);
			old.second = now->second;
//			os_printf("%s,begin=%u \r\n",buff+16,x_begin);
		}
	}

	if(!is_conn && conn){
		ssd1306_draw_bitmap(116,3,wifi1210,10,12);
		ssd1306_refresh_gram2(116,126,48,63);
		is_conn = true;
	}else if(is_conn && conn == NULL){
		ssd1306_display_string(116,3,"  ",12,1);
		ssd1306_refresh_gram2(116,126,48,63);
		is_conn = false;
	}

#ifdef _SHT3X

	if(nCounts%10 == 0 &&  have_sht3x && sht3x_read(&temperature,&humidity)){

		SHT3X_T=temperature;
		SHT3X_H=humidity;

		os_memset(buff,0,32);

		if(t_part1 != temperature/1000){
			t_part1	= temperature/1000;
			os_sprintf(buff,"%3d",t_part1);
			ssd1306_draw_1616HZ(45,20,buff);
			ssd1306_refresh_gram2(45,70,24,47);
		}

		if(t_part2 != (temperature%1000)/10){
			os_sprintf(buff+4,"%02d",(temperature%1000)/10);
			ssd1306_draw_1616HZ(75,20,buff+4);
			ssd1306_refresh_gram2(75,91,24,47);
			t_part2 = (temperature%1000)/10;
		}

		if(h_part1 != humidity/1000){
			os_sprintf(buff+8,"%d",humidity/1000);
			ssd1306_draw_1616HZ(51,42,buff+8);
			ssd1306_refresh_gram2(51,67,0,23);
			h_part1 = humidity/1000;
		}

		if(h_part2 != (humidity%1000)/10){
			os_sprintf(buff+12,"%02d",(humidity%1000)/10);
			ssd1306_draw_1616HZ(75,42,buff+12);
			ssd1306_refresh_gram2(75,91,0,23);
			h_part2 = (humidity%1000)/10;
		}
	}
#endif
}

#endif

ICACHE_FLASH_ATTR
void user_test(){

#ifdef _ILI9341

	ILI9341_setTextColor(ILI9341_YELLOW,ILI9341_BLUE);

	ILI9341_draw1616HZ(" TouchPos :",10,40);

	ILI9341_fillRect(15, 90, 180, 45, ILI9341_RED);

	ILI9341_drawBitmap(150,165,g, 61, 59);

	ILI9341_fillCircle(75, 200, 50, ILI9341_YELLOW);

	ILI9341_draw1616HZ("������Ȼ ������� ������ˮ",16,290);

	os_timer_disarm(&display_time_timer);
	os_timer_setfn(&display_time_timer, (os_timer_func_t *)display_time_cb, NULL);
	os_timer_arm(&display_time_timer, 200, 1);

#endif

#ifdef _SSD1306
	if(have_ssd1306){
		ssd1306_draw_1616HZ(3,20,"�¶�:");
		ssd1306_draw_1616HZ(69,20,".");
		ssd1306_draw_1616HZ(97,20,"��");
		ssd1306_draw_1616HZ(3,42,"ʪ��:");
		ssd1306_draw_1616HZ(69,42,".");
		ssd1306_draw_1616HZ(101,42,"%");

		ssd1306_draw_1616HZ(45,20,"-99");
		ssd1306_draw_1616HZ(75,20,"99");
		ssd1306_draw_1616HZ(51,42,"99");
		ssd1306_draw_1616HZ(75,42,"99");

		ssd1306_refresh_gram();

		os_timer_disarm(&display_TH_timer);
		os_timer_setfn(&display_TH_timer, (os_timer_func_t *)display_TH_cb, NULL);
		os_timer_arm(&display_TH_timer, 200, 1);
	}
#endif
}

#endif
