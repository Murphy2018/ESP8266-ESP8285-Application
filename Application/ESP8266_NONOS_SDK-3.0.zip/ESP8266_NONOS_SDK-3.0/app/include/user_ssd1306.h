#define SSD1306_ADDRESS    0x78

#define SSD1306_CMD    		0
#define SSD1306_DAT    		1
#define SSD1306_WIDTH    	128
#define SSD1306_HEIGHT   	64

#define __SET_COL_START_ADDR(low,high) 	do { \
											ssd1306_write_byte((low), SSD1306_CMD); \
											ssd1306_write_byte((high), SSD1306_CMD); \
										} while(false)

#ifdef __cplusplus
extern "C"
{
#endif

extern const  u8 wifi1210[24];

void ssd1306_init();
void ssd1306_auto_off(u8 begin,u8 end);
void ssd1306_display_on(void);
void ssd1306_display_off(void);
void ssd1306_refresh_gram(void);
void ssd1306_refresh_gram2(u8 x_begin,u8 x_end,u8 y_begin,u8 y_end);
void ssd1306_clear_screen(uint8_t chFill);
void ssd1306_draw_point(uint8_t chXpos, uint8_t chYpos, uint8_t chPoint);
void ssd1306_fill_screen(uint8_t chXpos1, uint8_t chYpos1, uint8_t chXpos2, uint8_t chYpos2, uint8_t chDot);
uint8_t ssd1306_display_char(uint8_t chXpos, uint8_t chYpos, uint8_t chChr, uint8_t chSize, uint8_t chMode);
void ssd1306_display_string(uint8_t chXpos, uint8_t chYpos, const uint8_t *pchString, uint8_t chSize, uint8_t chMode);
void ssd1306_draw_bitmap(uint8_t chXpos, uint8_t chYpos, const uint8_t *pchBmp, uint8_t chWidth, uint8_t chHeight);
void ssd1306_draw_1616HZ(uint8_t chXpos, uint8_t chYpos, uint8_t *s);
									

#ifdef __cplusplus
}
#endif
