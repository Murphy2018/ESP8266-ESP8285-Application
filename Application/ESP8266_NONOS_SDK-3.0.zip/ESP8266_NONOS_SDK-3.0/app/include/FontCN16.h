#include "os_type.h"

#define hz16_num  18

#ifdef __cplusplus
extern "C"
{
#endif

extern const  uint8 Index[hz16_num*2];
extern const  uint8 hz1616[hz16_num][32];

#ifdef __cplusplus
}
#endif
