#define TOUCH_CS_HIGH		{GPIO_OUTPUT_SET(_TOUCH_CS, 1);}
#define TOUCH_CS_LOW		{if(0XFF != _ILI9341_CS) GPIO_OUTPUT_SET(_ILI9341_CS, 1);\
								GPIO_OUTPUT_SET(_TOUCH_CS, 0);}
#define _swap(x, y) 		do { typeof(x) temp##x##y = x; x = y; y = temp##x##y; } while (0)
	

typedef enum  { ROT0, ROT90, ROT180, ROT270 }rotation_t;
typedef enum  { MODE_SER, MODE_DFR }adc_ref_t;

#ifdef __cplusplus
extern "C"
{
#endif

void xpt2046_init(u8 cs,u8 pen,u16 width,u16 height);
void xpt2046_setCalibration (uint16_t vi1, uint16_t vj1, uint16_t vi2, uint16_t vj2);
void xpt2046_setRotation(rotation_t rot);
void xpt2046_getPosition (uint16_t *x, uint16_t *y);
bool xpt2046_isTouching();

#ifdef __cplusplus
}
#endif
