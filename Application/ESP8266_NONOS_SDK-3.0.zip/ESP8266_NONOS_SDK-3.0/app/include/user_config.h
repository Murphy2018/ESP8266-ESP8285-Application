/*
 * ESPRESSIF MIT License
 *
 * Copyright (c) 2016 <ESPRESSIF SYSTEMS (SHANGHAI) PTE LTD>

 */

#ifndef __USER_CONFIG_H__
#define __USER_CONFIG_H__

#include "user_i2c.h"

//#define debug_on

#define _XPT2046

#define _ILI9341

#define _SSD1306

//#define _SHT3X

#if defined(_SSD1306)||defined(_ILI9341)
	#define LOAD_FONTCN16		//  ILI9341,SSD1306
//	#define LOAD_FONT32			//  ILI9341
//	#define LOAD_FONT64			//  ILI9341
//	#define LOAD_FONT7			//  ILI9341
#endif

#define _TEST

#endif

