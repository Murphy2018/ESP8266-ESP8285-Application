/*
 * ESPRESSIF MIT License
 *
 * Copyright (c) 2016 <ESPRESSIF SYSTEMS (SHANGHAI) PTE LTD>

 */

#ifndef __USER_CONFIG_H__
#define __USER_CONFIG_H__

#include "driver/i2c_master.h"

//#define ESP_PLATFORM        0
//#define LEWEI_PLATFORM      0
//
//#define USE_OPTIMIZE_PRINTF

//#define debug_on


//#define ESP8266

#define ESP8285

#ifdef ESP8266
#if defined(I2C_MASTER_SCL_MUX)
#undef I2C_MASTER_SCL_MUX
#define I2C_MASTER_SCL_MUX PERIPHS_IO_MUX_GPIO0_U
#endif
#if defined(I2C_MASTER_SCL_GPIO)
#undef I2C_MASTER_SCL_GPIO
#define I2C_MASTER_SCL_GPIO 0
#endif
#if defined(I2C_MASTER_SCL_FUNC)
#undef I2C_MASTER_SCL_FUNC
#define I2C_MASTER_SCL_FUNC FUNC_GPIO0
#endif
#endif

#ifdef ESP8285
#if defined(I2C_MASTER_SCL_MUX)
#undef I2C_MASTER_SCL_MUX
#define I2C_MASTER_SCL_MUX PERIPHS_IO_MUX_GPIO4_U
#endif
#if defined(I2C_MASTER_SCL_GPIO)
#undef I2C_MASTER_SCL_GPIO
#define I2C_MASTER_SCL_GPIO 4
#endif
#if defined(I2C_MASTER_SCL_FUNC)
#undef I2C_MASTER_SCL_FUNC
#define I2C_MASTER_SCL_FUNC FUNC_GPIO4
#endif
#endif

#define _XPT2046

#define _ILI9341

#define _SSD1306

#define _SHT3X


#if defined(_SSD1306)||defined(_ILI9341)
	#define LOAD_FONTCN16		//  ILI9341,SSD1306
//	#define LOAD_FONT32			//  ILI9341
//	#define LOAD_FONT64			//  ILI9341
//	#define LOAD_FONT7			//  ILI9341
#endif

#define _TEST

#endif

