

#ifndef __USER_COMMON
#define __USER_COMMON

#include "ets_sys.h"
#include "osapi.h"
#include "queue.h"

#define CFG_MAGIC "ABCDEF0"
#define cfg_is_enable(x,pos) ((x)&(0x01 << (pos-1)))
#define cfg_enable(x,pos) (x)=((x)|(0x01 << (pos-1)))
#define cfg_disable(x,pos) (x)=((x)&(~(0x01 << (pos-1))))

struct ap_info{
	char bssid[6];
	u8  ssid[32];
	u8	channel;
	s8	rssi;
	u8	hidden;
	char auth_mode[16];
};

struct mycfg{
	char flag[8];

	// 1bit id,2bit master_ssid,3bit secondary_ssid
	// 4bit master_autopost_server,5bit secondary_autopost_server
	// 6bit autopost switch, 7bit display_title switch
	// 8bit oled_off timer
	u32	 enable;

	char id[16];
	char main_ssid[32];
	char main_ssid_password[64];
	char secondary_ssid[32];
	char secondary_ssid_password[64];
	char main_autopost_server[16];
	u32  main_autopost_server_port;
	char secondary_autopost_server[16];
	u32  secondary_autopost_server_port;
	u32  bautopost:16;
	u32  autopost_interval:16;
	char display_title[16];
	u32   oled_off_begin:16;
	u32   oled_off_end:16;
};

struct datetime{
	u32  year:6;
	u32  month:4;
	u32  day:5;
	u32  hour:5;
	u32  minute:6;
	u32  second:6;
};

struct dataHistory{
	STAILQ_ENTRY(dataHistory) next;
	struct datetime when;
	s32 temperature;
	s32 humidity;
};

#ifdef __cplusplus
extern "C"
{
#endif


bool write_mycfg_to_flash();
bool read_mycfg_from_flash();
void* get_sys_time();
bool pinFunc_p(u8 pin,bool pullup);

#ifdef __cplusplus
}
#endif

#endif
