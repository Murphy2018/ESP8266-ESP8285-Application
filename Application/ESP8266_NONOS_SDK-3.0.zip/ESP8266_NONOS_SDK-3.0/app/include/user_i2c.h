#ifndef _user_i2c_h
#define _user_i2c_h

#include "driver/i2c_master.h"

extern u8 _I2C_SCL ;
extern u8 _I2C_SCL_FUNC ;
extern u32 _I2C_SCL_MUX ;

extern u8 _I2C_SDA ;
extern u8 _I2C_SDA_FUNC ;
extern u32 _I2C_SDA_MUX ;

#if defined(I2C_MASTER_SCL_MUX)
#undef I2C_MASTER_SCL_MUX
#define I2C_MASTER_SCL_MUX _I2C_SCL_MUX
#endif
#if defined(I2C_MASTER_SCL_GPIO)
#undef I2C_MASTER_SCL_GPIO
#define I2C_MASTER_SCL_GPIO _I2C_SCL
#endif
#if defined(I2C_MASTER_SCL_FUNC)
#undef I2C_MASTER_SCL_FUNC
#define I2C_MASTER_SCL_FUNC _I2C_SCL_FUNC
#endif

#if defined(I2C_MASTER_SDA_MUX)
#undef I2C_MASTER_SDA_MUX
#define I2C_MASTER_SDA_MUX _I2C_SDA_MUX
#endif
#if defined(I2C_MASTER_SDA_GPIO)
#undef I2C_MASTER_SDA_GPIO
#define I2C_MASTER_SDA_GPIO _I2C_SDA
#endif
#if defined(I2C_MASTER_SDA_FUNC)
#undef I2C_MASTER_SDA_FUNC
#define I2C_MASTER_SDA_FUNC _I2C_SDA_FUNC
#endif


#ifdef __cplusplus
extern "C"
{
#endif

bool i2c_pin(u8 SCL,u8 SDA);

#ifdef __cplusplus
}
#endif

#endif
