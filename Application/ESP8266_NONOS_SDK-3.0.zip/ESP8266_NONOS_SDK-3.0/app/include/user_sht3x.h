#define SHT3X_Addr    	0x44

#define CRC8_POLYNOMIAL	0x31
#define CRC8_INIT		0xFF
#define CRC8_LEN 		1

#ifdef __cplusplus
extern "C"
{
#endif

void sht3x_init();
bool sht3x_read(s32 *temperature, s32 *humidity);


#ifdef __cplusplus
}
#endif
