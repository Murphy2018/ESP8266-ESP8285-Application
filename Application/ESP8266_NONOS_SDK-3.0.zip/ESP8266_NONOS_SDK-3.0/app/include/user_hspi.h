#ifndef _user_hspi_h
#define _user_hspi_h

#ifdef __cplusplus
extern "C"
{
#endif

void hspi_setFrequency(uint32_t freq);
void hspi_init(u8 clk_polar,uint32_t freq);
uint8_t hspi_transfer(uint8_t data);
uint16_t hspi_transfer16(uint16_t data);
void hspi_write(uint8_t data);
void hspi_write16(uint16_t data);
void hspi_write32(uint32_t data);
void hspi_writeBytes(const uint8_t * data, uint32_t size);

#ifdef __cplusplus
}
#endif

#endif
