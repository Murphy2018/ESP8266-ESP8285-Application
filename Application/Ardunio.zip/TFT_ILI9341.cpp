/*
 2012 Copyright (c) Seeed Technology Inc.

 Authors: Albert.Miao & Loovee,
 Visweswara R (with initializtion code from TFT vendor)

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc.,51 Franklin St,Fifth Floor, Boston, MA 02110-1301 USA

*/

#include "TFT_ILI9341.h"

#include <SPI.h>

#include "user_config.h"


#ifdef LOAD_FONT16
#include "Font16.h"
#endif

#ifdef LOAD_FONT32
#include "Font32.h"
#endif

#ifdef LOAD_FONT64
#include "Font64.h"
#endif

#ifdef LOAD_FONT7
#include "Font7s.h"
#endif


ICACHE_FLASH_ATTR
void TFT::TFTinit (uint8_t CS,uint8_t DC,uint8_t RES,uint16 width,uint16 height,TFT_COLOR screenBackColor)
{
	_CS = CS;
	_DC = DC;
	_RES = RES;

	pinMode( CS,OUTPUT);
	pinMode( DC,OUTPUT);
	pinMode( RES,OUTPUT);
 
	TFT_CS_LOW;
	
	TFT_RST_CLR;
	os_delay_us(10000);
	TFT_RST_SET;
	os_delay_us(1000);

 	uint8_t data[16] = {0};

	data[0] = 0x39;
	data[1] = 0x2C;
	data[2] = 0x00;
	data[3] = 0x34;
	data[4] = 0x02;
	sendCMD(0xCB, data, 5);		//Power control A

	data[0] = 0x00;
	data[1] = 0XC1;
	data[2] = 0X30;
	sendCMD(0xCF, data, 3);		//Power control B

	data[0] = 0x85;
	data[1] = 0x00;
	data[2] = 0x78;
	sendCMD(0xE8, data, 3);		// Driver timing control A

	data[0] = 0x00;
	data[1] = 0x00;
	sendCMD(0xEA, data, 2);		// Driver timing control B

	data[0] = 0x64;
	data[1] = 0x03;
	data[2] = 0X12;
	data[3] = 0X81;
	sendCMD(0xED, data, 4); 		//Power on sequence control

	data[0] = 0x20;
	sendCMD(0xF7, data, 1);		//Pump ratio control

	data[0] = 0x23;   	//VRH[5:0]
	sendCMD(0xC0, data, 1);    	//Power control

	data[0] = 0x10;   	//SAP[2:0];BT[3:0]
	sendCMD(0xC1, data, 1);    	//Power control

	data[0] = 0x3e;   	
	data[1] = 0x28;
	sendCMD(0xC5, data, 2);    	//VCM control

	data[0] = 0x86;  	 //--
	sendCMD(0xC7, data, 1);    	//VCM control2

	data[0] = 0x48;  	//C8
	sendCMD(0x36, data, 1);    	// Memory Access Control

	data[0] = 0x55;
	sendCMD(0x3A, data, 1);		//COLMOD: Pixel Format Set

	data[0] = 0x6F;
	sendCMD(0x51, data, 1);		//Write Display Brightness

	data[0] = 0x00;
	data[1] = 0x18;
	sendCMD(0xB1, data, 2);		//Frame Rate Control (In Normal Mode/Full Colors)

	data[0] = 0x08;
	data[1] = 0x82;
	data[2] = 0x27;
	sendCMD(0xB6, data, 3);    	// Display Function Control

	data[0] = 0x00;
	sendCMD(0xF2, data, 1);    	// 3Gamma Function Disable

	data[0] = 0x01;
	sendCMD(0x26, data, 1);    	//Gamma curve selected

	data[0] = 0x0F;
	data[1] = 0x31;
	data[2] = 0x2B;
	data[3] = 0x0C;
	data[4] = 0x0E;
	data[5] = 0x08;
	data[6] = 0x4E;
	data[7] = 0xF1;
	data[8] = 0x37;
	data[9] = 0x07;
	data[10] = 0x10;
	data[11] = 0x03;
	data[12] = 0x0E;
	data[13] = 0x09;
	data[14] = 0x00;
	sendCMD(0xE0, data, 15);    	//Set Gamma

	data[0] = 0x00;
	data[1] = 0x0E;
	data[2] = 0x14;
	data[3] = 0x03;
	data[4] = 0x11;
	data[5] = 0x07;
	data[6] = 0x31;
	data[7] = 0xC1;
	data[8] = 0x48;
	data[9] = 0x08;
	data[10] = 0x0F;
	data[11] = 0x0C;
	data[12] = 0x31;
	data[13] = 0x36;
	data[14] = 0x0F;
	sendCMD(0xE1, data, 15);    	//Set Gamma

	sendCMD(0x11);    		//Exit Sleep
	os_delay_us(120000);

	sendCMD(0x29);    		//Display on	
	
	_screenBackColor = screenBackColor;
	_width = width;
	_height = height;

	fillRectangle(0,0,width,height, screenBackColor);
}

ICACHE_FLASH_ATTR
INT8U TFT::readID(void)
{
    INT8U i=0;
    INT8U data[3] ;
    INT8U ID[3] = {0x00, 0x93, 0x41};
    INT8U ToF=1;

	sendCMD(0xD3);

    for(i=0;i<3;i++)
    {
        data[i]=Read_Register(0xd3,i+1);
        if(data[i] != ID[i])
        {
            ToF=0;
        }
    }
    if(!ToF)                                                            /* data!=ID                     */
    {
        Serial.print("Read TFT ID failed, ID should be 0x09341, but read ID = 0x");
        for(i=0;i<3;i++)
        {
            Serial.print(data[i],HEX);
        }
        Serial.println();
    }
    return ToF;
}

ICACHE_FLASH_ATTR
void TFT::setAddrWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {

	INT8U data[4] = { 0 };

	data[0] = x0 >> 8;
	data[1] = x0 & 0xFF;
	data[2] = x1 >> 8;
	data[3] = x1 & 0xFF;
	sendCMD(0x2A, data,4);

	data[0] = y0 >> 8;
	data[1] = y0 & 0xFF;
	data[2] = y1 >> 8;
	data[3] = y1 & 0xFF;
	sendCMD(0x2B, data, 4);
}

ICACHE_FLASH_ATTR
void TFT::fillRectangle(INT16U x, INT16U y, INT16U w, INT16U h, INT16U color)
{
	if ((x >= _width) || (y >= _height)) return;
	if ((x + w - 1) >= _width)  w = _width - x;
	if ((y + h - 1) >= _height) h = _height - y;
    
	setAddrWindow(x, y, x + w - 1, y + h - 1);

	sendCMD(0x2C);

	TFT_DC_HIGH;
    TFT_CS_LOW;

    //INT8U Hcolor = color>>8;
    //INT8U Lcolor = color&0xff;


    for(int i=0; i < w*h; i++)
    {
        //SPI.write(Hcolor);
        //SPI.write(Lcolor);
		SPI.write16(color);
    }


    TFT_CS_HIGH;
}

ICACHE_FLASH_ATTR
void TFT::setXY(INT16U poX, INT16U poY)
{
	setAddrWindow(poX,poY,poX, poY);
}

ICACHE_FLASH_ATTR
void TFT::setPixel(INT16U poX, INT16U poY, INT16U color)
{
	setXY(poX, poY);

    sendCMD(0x2c);

    sendData(color);
}

ICACHE_FLASH_ATTR
void TFT::getPixel(INT16U poX, INT16U poY, INT16U &color)
{
	INT16U R, G, B;

	INT8U data[4] = { 0 };

	setXY(poX, poY);

	sendCMD(0x2E);

	 for (int i = 0; i < 4; i++)
	{
		data[i] = Read_Register(0x2E, i + 1);
		//Serial.printf("[%u:0x%02X]  ",i, data[i]);
	}
	
	Serial.println();

	R = (data[1] >> 3) & 0x00ff;
	G = (data[2] >> 2) & 0x00ff;
	B = (data[3] >> 3) & 0x00ff;

	color = (R << 11) | (G << 5) | (B);

}

ICACHE_FLASH_ATTR
void TFT::setTextColor(INT16U c, INT16U b) {
	_textColor = c;
	_textBackColor = b;
}

ICACHE_FLASH_ATTR
uint16_t TFT::drawChar(INT8U uniCode, INT16U x, INT16U y,INT16U size)
{
	if (size) uniCode -= 32;

	uint16_t width = 0;
	uint16_t height = 0;
	const uint8_t *flash_address = 0;
	int8_t gap = 0;

#ifdef LOAD_FONT16
	if (size == 16) {
		flash_address = chrtbl_f16[uniCode];
		width = *(widtbl_f16 + uniCode);
		height = chr_hgt_f16;
		gap = 1;
	}
#endif

#ifdef LOAD_FONT32
	if (size == 32) {
		flash_address = chrtbl_f32[uniCode];
		width = *(widtbl_f32 + uniCode);
		height = chr_hgt_f32;
		gap = -3;
	}
#endif

#ifdef LOAD_FONT64
	if (size == 64) {
		flash_address = chrtbl_f64[uniCode];
		width = *(widtbl_f64 + uniCode);
		height = chr_hgt_f64;
		gap = -3;
	}
#endif
#ifdef LOAD_FONT7
	if (size == 7) {
		flash_address = chrtbl_f7s[uniCode];
		width = *(widtbl_f7s + uniCode);
		height = chr_hgt_f7s;
		gap = 2;
	}
#endif

	uint16_t w = (width + 7) / 8;
	uint16_t pX = 0;
	uint16_t pY = y;
	uint16_t color = 0;
	uint8_t line = 0;

	uint16_t i, k;

	for (i = 0; i < height; i++)
	{
		if (_textColor != _textBackColor) drawFastHLine(x, pY, width + gap, _textBackColor);
		for (k = 0; k < w; k++)
		{
			line = *(flash_address + w * i + k);
			if (line) {
				pX = x + k * 8;
				if (line & 0x80) setPixel(pX, pY, _textColor);
				if (line & 0x40) setPixel(pX + 1, pY, _textColor);
				if (line & 0x20) setPixel(pX + 2, pY, _textColor);
				if (line & 0x10) setPixel(pX + 3, pY, _textColor);
				if (line & 0x8) setPixel(pX + 4, pY, _textColor);
				if (line & 0x4) setPixel(pX + 5, pY, _textColor);
				if (line & 0x2) setPixel(pX + 6, pY, _textColor);
				if (line & 0x1) setPixel(pX + 7, pY, _textColor);
			}
		}
		pY++;
	}
	return width + gap;        // x +
}

ICACHE_FLASH_ATTR
uint16_t TFT::drawString(const char *string,INT16U poX, INT16U poY, INT16U size)
{
	uint16_t sumX = 0;

	while (*string)
	{
		uint16_t xPlus = drawChar(*string++, poX, poY, size);
		sumX += xPlus;
		poX += xPlus;                                     /* Move cursor right            */
	}

	return sumX;
}

ICACHE_FLASH_ATTR
void  TFT::drawFastHLine( INT16U x, INT16U y ,INT16U w,INT16U color)
{
	if ((x >= _width) || (y >= _height)) return;
	if ((x + w - 1) >= _width)  w = _width - x;

	setAddrWindow(x, y, x+ w-1, y);

    sendCMD(0x2c);

    for(INT16U i=0; i<w; i++)
		sendData(color);
}

ICACHE_FLASH_ATTR
void TFT::drawFastVLine(INT16U x, INT16U y, INT16U h, INT16U color)
{
	if ((x >= _width) || (y >= _height)) return;
	if ((y + h - 1) >= _height) h = _height - y;

	setAddrWindow(x, y, x, y + h - 1);

	sendCMD(0x2c);

	for (INT16U i = 0; i < h; i++)
		sendData(color);
}

ICACHE_FLASH_ATTR
void TFT::drawLine( INT16U x0,INT16U y0,INT16U x1, INT16U y1,INT16U color)
{

    int x = x1-x0;
    int y = y1-y0;
    int dx = abs(x), sx = x0<x1 ? 1 : -1;
    int dy = -abs(y), sy = y0<y1 ? 1 : -1;
    int err = dx+dy, e2;                                                /* error value e_xy             */
    for (;;)
    {                                                                   /* loop                         */
        setPixel(x0,y0,color);
        e2 = 2*err;
        if (e2 >= dy) {                                                 /* e_xy+e_x > 0                 */
            if (x0 == x1) break;
            err += dy; x0 += sx;
        }
        if (e2 <= dx) {                                                 /* e_xy+e_y < 0                 */
            if (y0 == y1) break;
            err += dx; y0 += sy;
        }
    }
}

ICACHE_FLASH_ATTR
void TFT::drawRectangle(INT16U x, INT16U y, INT16U w, INT16U h,INT16U color)
{
	drawFastHLine(x, y, w, color);
	drawFastHLine(x, y+h, w, color);
	drawFastVLine(x, y, h,color);
	drawFastVLine(x + w, y, h,color);
}

ICACHE_FLASH_ATTR
void TFT::drawCircle(int poX, int poY, int r,INT16U color)
{
    int x = -r, y = 0, err = 2-2*r, e2;
    do {
        setPixel(poX-x, poY+y,color);
        setPixel(poX+x, poY+y,color);
        setPixel(poX+x, poY-y,color);
        setPixel(poX-x, poY-y,color);
        e2 = err;
        if (e2 <= y) {
            err += ++y*2+1;
            if (-x == y && e2 <= x) e2 = 0;
        }
        if (e2 > x) err += ++x*2+1;
    } while (x <= 0);
}

ICACHE_FLASH_ATTR
void TFT::fillCircle(int poX, int poY, int r,INT16U color)
{
    int x = -r, y = 0, err = 2-2*r, e2;
    do {

		drawFastVLine(poX-x, poY-y, 2*y, color);
		drawFastVLine(poX+x, poY-y, 2*y, color);

        e2 = err;
        if (e2 <= y) {
            err += ++y*2+1;
            if (-x == y && e2 <= x) e2 = 0;
        }
        if (e2 > x) err += ++x*2+1;
    } while (x <= 0);

}

ICACHE_FLASH_ATTR
void TFT::drawTraingle( int poX1, int poY1, int poX2, int poY2, int poX3, int poY3, INT16U color)
{
    drawLine(poX1, poY1, poX2, poY2,color);
    drawLine(poX1, poY1, poX3, poY3,color);
    drawLine(poX2, poY2, poX3, poY3,color);
}

ICACHE_FLASH_ATTR
void TFT::drawBitmap(int16_t x, int16_t y, const uint8_t *bitmap, int16_t w, int16_t h) {
	uint16_t j, i;

	uint16_t c;

	setAddrWindow(x,y,x+w-1,y+h-1);
	sendCMD(0X2C);

	TFT_DC_HIGH;
	TFT_CS_LOW;


	for(j=0; j<h; j++) {
		for(i=0; i<w; i++ ) {
			c = (uint16_t)((bitmap[2*j*w + 2*i]<<8) | (bitmap[2*j*w + 2*i+1]));
			SPI.write16(c);
		}
	}


	TFT_CS_HIGH

	//for (j = 0; j < h; j++) {
	//	for (i = 0; i < w; i++) {
	//		setPixel(x + i, y + j, ((bitmap[2 * j*w + 2 * i] << 8) | (bitmap[2 * j*w + 2 * i + 1])));
	//	}
	//}

}

#if !defined(NO_GLOBAL_INSTANCES) && !defined(NO_GLOBAL_TFT)
TFT Tft;
#endif

/*********************************************************************************************************
  END FILE
*********************************************************************************************************/
