/*
 2012 Copyright (c) Seeed Technology Inc.

 Authors: Albert.Miao & Loovee, 
 Visweswara R (with initializtion code from TFT vendor)

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Modified by Sermus for ESP8266
*/
#ifndef TFT_ILI9341
#define TFT_ILI9341

#if defined(ARDUINO) && ARDUINO >= 100
#define SEEEDUINO
#include <Arduino.h>
#else
#include <WProgram.h>
#endif

#include <pgmspace.h>
#include <SPI.h>

#include "XPT2046.h"


//TFT resolution 240*320
#define MIN_X	0
#define MIN_Y	0
#define MAX_X	239
#define MAX_Y	319

//#define TFT_CS_LOW  {if(pinCS==1){digitalWrite(pinCS, 0);pinCS=0;}}
//#define TFT_CS_HIGH {if(pinCS==0){digitalWrite(pinCS, 1);pinCS=1;}}

#define TFT_CS_LOW  digitalWrite(_CS, 0);
#define TFT_CS_HIGH digitalWrite(_CS, 1);

#define TFT_DC_LOW  digitalWrite(_DC, 0);
#define TFT_DC_HIGH digitalWrite(_DC, 1);

#define TFT_RST_CLR		digitalWrite(_RES, 0);
#define TFT_RST_SET 	digitalWrite(_RES, 1);

#define YP A2   // must be an analog pin, use "An" notation!
#define XM A1   // must be an analog pin, use "An" notation!
#define YM 14   // can be a digital pin, this is A0
#define XP 17   // can be a digital pin, this is A3

#define TS_MINX 116*2
#define TS_MAXX 890*2
#define TS_MINY 83*2
#define TS_MAXY 913*2

#ifndef INT8U
#define INT8U unsigned char
#endif
#ifndef INT16U
#define INT16U unsigned int
#endif

#define FONT_SPACE 6
#define FONT_X 8
#define FONT_Y 8


extern INT8U simpleFont[][8];

extern XPT2046 Touch;

typedef enum {
	RED			=0xf800,
	GREEN		=0x07e0,
	BLUE		=0x001f,
	BLACK		=0x0000,
	YELLOW		=0xffe0,
	WHITE		=0xffff,
	CYAN		=0x07ff,
	BRIGHT_RED	=0xf810,	
	GRAY1		=0x8410,  
	GRAY2		=0x4208  
}TFT_COLOR;


class TFT
{

private:
	uint8_t _CS;
	uint8_t _DC;
	uint8_t _RES;

	uint16 _screenBackColor;
	uint16 _textColor;
	uint16 _textBackColor;

	uint16_t _width;
	uint16_t _height;

public:

	inline uint16_t getWidth() { return _width;}

	inline uint16_t getHeight() { return _height;}

    inline void sendCMD(INT8U index)
    {
        TFT_DC_LOW;
        TFT_CS_LOW;

        SPI.write(index);

        TFT_CS_HIGH;
    }

	inline void sendCMD(INT8U cmd,INT8U* data, INT8U len)
	{
		if (len < 0 || data == NULL)
			return;

		TFT_DC_LOW;
		TFT_CS_LOW;

		SPI.write(cmd);
		TFT_DC_HIGH;
		SPI.writeBytes(data,len);

		TFT_CS_HIGH;
	}

    inline void WRITE_DATA(INT8U data)
    {
        TFT_DC_HIGH;
        TFT_CS_LOW;

        SPI.write(data);

        TFT_CS_HIGH;
    }
    
    inline void sendData(INT16U data)
    {
        INT8U data1 = data>>8;
        INT8U data2 = data&0xff;
        TFT_DC_HIGH;
        TFT_CS_LOW;

        SPI.write(data1);
        SPI.write(data2);

        TFT_CS_HIGH;
    }

    //void WRITE_Package(INT16U *data, INT8U howmany)
    //{
    //    INT16U  data1 = 0;
    //    INT8U   data2 = 0;
    //    TFT_DC_HIGH;
    //    TFT_CS_LOW;
    //    INT8U count=0;
    //    for(count=0;count<howmany;count++)
    //    {
    //        data1 = data[count]>>8;
    //        data2 = data[count]&0xff;
    //        SPI.transfer(data1);
    //        SPI.transfer(data2);
    //    }
    //    TFT_CS_HIGH;
    //}

    INT8U Read_Register(INT8U Addr, INT8U xParameter)
    {
        INT8U data=0;

		//os_delay_us(5);

        sendCMD(0xD9);                                                      /* ext command                  */
        WRITE_DATA(0x10+xParameter);                                        /* 0x11 is the first Parameter  */
		
		//os_delay_us(5);

		TFT_CS_LOW;
		TFT_DC_LOW;

		SPI.transfer(Addr);

        TFT_DC_HIGH;
        data = SPI.transfer(0);
        TFT_CS_HIGH;
		
        return data;
    }
	    
	void TFTinit(uint8_t CS, uint8_t DC, uint8_t RES, uint16 width, uint16 height, TFT_COLOR screenBackColor);

	void setAddrWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1);

	void setXY(INT16U poX, INT16U poY);
    void setPixel(INT16U poX, INT16U poY,INT16U color);
	void getPixel(INT16U poX, INT16U poY, INT16U &color);

	INT8U readID(void);

	inline uint16_t color565(uint8_t r, uint8_t g, uint8_t b) {
		return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
	};

	void setTextColor(INT16U c, INT16U b);
	uint16_t drawChar(INT8U ascii,INT16U poX, INT16U poY,INT16U size);
	uint16_t drawString(const char *string,INT16U poX, INT16U poY,INT16U size);

	void drawBitmap(int16_t x, int16_t y, const uint8_t *bitmap, int16_t w, int16_t h);

	void fillRectangle(INT16U poX, INT16U poY, INT16U length, INT16U width, INT16U color);
	
	void drawLine(INT16U x0,INT16U y0,INT16U x1,INT16U y1,INT16U color);
    void drawFastVLine(INT16U poX, INT16U poY,INT16U length,INT16U color);
    void drawFastHLine(INT16U poX, INT16U poY,INT16U length,INT16U color);
    void drawRectangle(INT16U poX, INT16U poY, INT16U length,INT16U width,INT16U color);
	
	void drawCircle(int poX, int poY, int r,INT16U color);
    void fillCircle(int poX, int poY, int r,INT16U color);
	
	void drawTraingle(int poX1, int poY1, int poX2, int poY2, int poX3, int poY3, INT16U color);
    
    //INT8U drawNumber(long long_num,INT16U poX, INT16U poY,INT16U size,INT16U fgcolor);
    //INT8U drawFloat(float floatNumber,INT8U decimal,INT16U poX, INT16U poY,INT16U size,INT16U fgcolor);
    //INT8U drawFloat(float floatNumber,INT16U poX, INT16U poY,INT16U size,INT16U fgcolor);

};

#if !defined(NO_GLOBAL_INSTANCES) && !defined(NO_GLOBAL_TFT)
extern TFT Tft;
#endif

#endif

/*********************************************************************************************************
  END FILE
*********************************************************************************************************/
