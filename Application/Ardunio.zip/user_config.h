/*
 * ESPRESSIF MIT License
 *
 * Copyright (c) 2016 <ESPRESSIF SYSTEMS (SHANGHAI) PTE LTD>

 */

#ifndef __USER_CONFIG_H__
#define __USER_CONFIG_H__

//#define debug_on

#define LOAD_FONT16
//#define LOAD_FONT32
//#define LOAD_FONT64
//#define LOAD_FONT7


#define _ILI9341

#define _XPT2046

#endif

